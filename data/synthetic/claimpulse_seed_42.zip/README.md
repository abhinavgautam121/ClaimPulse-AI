# ClaimPulse AI synthetic seed dataset

This archive contains 20,000 independently generated synthetic claims, seed 42, and 13 related CSV tables. No real patient information or user credentials are included.

Dates are anchored to the seed date recorded in manifest.json. All money is USD. Claim patient IDs are SYN- references. Expected insurer reimbursement is a labelled synthetic assumption of 72% of billed charges.

Table row counts and per-file SHA-256 hashes are recorded in manifest.json. Claims, payments, denials, appeals and lifecycle events retain their relationships.

For the app, normal bootstrap recreates the dataset using backend/app/services/seed.py. For offline analytics, extract the CSVs and load with Pandas. The browser uploader accepts at most 10,000 rows per job, so split claims.csv into two batches when using that interface. Existing claim IDs are reported as duplicates and never silently overwritten.

Run python scripts/verify_synthetic_data.py from the source repository to verify this archive.
